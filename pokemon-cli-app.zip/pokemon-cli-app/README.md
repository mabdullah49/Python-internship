# 🎮 Pokémon Info CLI App

An interactive Python app that fetches data from the PokéAPI based on user input.

## 🔧 Features
- Enter any Pokémon name
- Displays types, abilities, and base stats
- Optional save to local `.txt` file
- CLI menu for smooth interaction
- Error handling included

## ▶️ How to Run
```bash
pip install -r requirements.txt
python interactive_api.py
```

## 🌐 API Used
[https://pokeapi.co](https://pokeapi.co)

#ProSensiaInternship #Python #API #Pokémon
