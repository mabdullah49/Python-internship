
import requests
import json

def fetch_pokemon_data(name):
    url = f"https://pokeapi.co/api/v2/pokemon/{name.lower()}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def display_data(data):
    print("\n--- Pokémon Information ---")
    print(f"Name: {data['name'].title()}")
    print("Types:", ', '.join([t['type']['name'].title() for t in data['types']]))
    print("Abilities:", ', '.join([a['ability']['name'].title() for a in data['abilities']]))
    print("Base Stats:")
    for stat in data['stats']:
        print(f"  {stat['stat']['name'].title()}: {stat['base_stat']}")

def save_to_file(data):
    filename = f"{data['name']}_info.txt"
    with open(filename, 'w') as f:
        f.write(f"Name: {data['name'].title()}\n")
        f.write(f"Types: {', '.join([t['type']['name'].title() for t in data['types']])}\n")
        f.write(f"Abilities: {', '.join([a['ability']['name'].title() for a in data['abilities']])}\n")
        f.write("Base Stats:\n")
        for stat in data['stats']:
            f.write(f"  {stat['stat']['name'].title()}: {stat['base_stat']}\n")
    print(f"\nData saved to {filename}")

def menu():
    while True:
        print("\nPokémon Info CLI")
        print("1. Search Pokémon")
        print("2. Exit")
        choice = input("Enter choice (1/2): ")

        if choice == '1':
            name = input("Enter Pokémon name: ")
            data = fetch_pokemon_data(name)
            if data:
                display_data(data)
                save = input("Do you want to save this info to a file? (y/n): ").lower()
                if save == 'y':
                    save_to_file(data)
            else:
                print("Pokémon not found. Please try again.")
        elif choice == '2':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1 or 2.")

if __name__ == "__main__":
    menu()
